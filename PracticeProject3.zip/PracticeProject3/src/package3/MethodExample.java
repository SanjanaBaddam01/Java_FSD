package package3;

public class MethodExample {

    // Method with no parameters and no return value (void)
    public static void printHello() {
        System.out.println("Hello, World!");
    }

    // Method with parameters and return value
    public static int addNumbers(int a, int b) {
        return a + b;
    }

    // Method with variable number of arguments
    public static int addMultipleNumbers(int... numbers) {
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        return sum;
    }

    public static void main(String[] args) {
        // Calling a method with no parameters and no return value
        printHello();

        // Calling a method with parameters and return value
        int result = addNumbers(5, 7);
        System.out.println("Result of adding numbers: " + result);

        // Calling a method with variable number of arguments
        int sum = addMultipleNumbers(1, 2, 3, 4, 5);
        System.out.println("Sum of multiple numbers: " + sum);

        // Storing the result of a method in a variable and using it later
        int a = 10;
        int b = 20;
        int sumResult = addNumbers(a, b);
        System.out.println("Sum of " + a + " and " + b + ": " + sumResult);

        // Directly using the result of a method in an expression
        int total = addNumbers(3, 4) + addNumbers(1, 2);
        System.out.println("Total: " + total);
    }
}
