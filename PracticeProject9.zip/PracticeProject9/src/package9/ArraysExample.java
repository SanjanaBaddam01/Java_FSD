package package9;

public class ArraysExample {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] intArray = {1, 2, 3, 4, 5};

        // Display the elements of the integer array
        System.out.println("Integer Array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }
        System.out.println();

        // Declare and initialize an array of strings
        String[] stringArray = {"Java", "Python", "C++", "JavaScript"};

        // Display the elements of the string array
        System.out.println("\nString Array:");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.print(stringArray[i] + " ");
        }
        System.out.println();

        // Declare and initialize a 2D array
        int[][] twoDArray = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        // Display the elements of the 2D array
        System.out.println("\n2D Array:");
        for (int i = 0; i < twoDArray.length; i++) {
            for (int j = 0; j < twoDArray[i].length; j++) {
                System.out.print(twoDArray[i][j] + " ");
            }
            System.out.println();
        }

    }
}