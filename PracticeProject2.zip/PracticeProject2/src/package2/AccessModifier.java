package package2;

//Public class with public access
public class AccessModifier {
 // Public variable
 public int publicVar = 10;

 // Private variable
 private int privateVar = 20;

 // Protected variable
 protected int protectedVar = 30;

 // Default (package-private) variable
 int defaultVar = 40;

 // Public method
 public void publicMethod() {
     System.out.println("Public method");
 }

 // Private method
 private void privateMethod() {
     System.out.println("Private method");
 }

 // Protected method
 protected void protectedMethod() {
     System.out.println("Protected method");
 }

 // Default (package-private) method
 void defaultMethod() {
     System.out.println("Default (package-private) method");
 }

 public static void main(String[] args) {
     AccessModifier example = new AccessModifier();

     // Accessing variables and methods from the same class
     System.out.println("Public variable: " + example.publicVar);
     System.out.println("Private variable: " + example.privateVar);
     System.out.println("Protected variable: " + example.protectedVar);
     System.out.println("Default variable: " + example.defaultVar);

     example.publicMethod();
     example.privateMethod();
     example.protectedMethod();
     example.defaultMethod();

     // Accessing the default (package-private) class from the same package
     DefaultAccessClass defaultAccessClass = new DefaultAccessClass();
     defaultAccessClass.display();
 }
}
