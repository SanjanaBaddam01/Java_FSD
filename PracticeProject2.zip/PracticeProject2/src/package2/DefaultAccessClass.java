package package2;

//This is a class with default (package-private) access
class DefaultAccessClass {
 void display() {
     System.out.println("Default (package-private) access class");
 }
}


