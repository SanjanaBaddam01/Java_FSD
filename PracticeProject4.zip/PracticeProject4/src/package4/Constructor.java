package package4;

public class Constructor {
    public static void main(String[] args) {
        // Creating objects using different constructors
        Car car1 = new Car();
        Car car2 = new Car("Toyota", "Camry", 2022);
        Car car3 = new Car("Honda", "Accord");

        // Displaying information for each car
        System.out.println("Car 1:");
        car1.displayInfo();

        System.out.println("Car 2:");
        car2.displayInfo();

        System.out.println("Car 3:");
        car3.displayInfo();
    }
}
