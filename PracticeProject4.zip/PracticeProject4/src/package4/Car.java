package package4;

class Car {
    String brand;
    String model;
    int year;

    // Default (no-argument) constructor
    public Car() {
        // Default values
        brand = "Unknown";
        model = "Unknown";
        year = 0;
    }

    // Parameterized constructor
    public Car(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
    }

    // Constructor chaining example
    public Car(String brand, String model) {
        // Call the parameterized constructor with an additional default value
        this(brand, model, 0);
    }

    // Method to display car information
    public void displayInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
        System.out.println();
    }
}

