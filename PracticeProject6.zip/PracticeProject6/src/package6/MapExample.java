package package6;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        // Creating a HashMap
        Map<String, Integer> populationMap = new HashMap<>();

        // Adding key-value pairs to the map
        populationMap.put("USA", 331000000);
        populationMap.put("China", 1444216107);
        populationMap.put("India", 1393409038);
        populationMap.put("Brazil", 213993437);

        // Retrieving and printing values
        System.out.println("Population of USA: " + populationMap.get("USA"));
        System.out.println("Population of China: " + populationMap.get("China"));

        // Checking if a key exists in the map
        String countryToCheck = "Japan";
        if (populationMap.containsKey(countryToCheck)) {
            System.out.println("Population of " + countryToCheck + ": " + populationMap.get(countryToCheck));
        } else {
            System.out.println(countryToCheck + " not found in the map.");
        }

        // Iterating over key-value pairs in the map
        System.out.println("\nIterating over the map:");
        for (Map.Entry<String, Integer> entry : populationMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Removing a key-value pair from the map
        String countryToRemove = "Brazil";
        System.out.println("\nRemoving " + countryToRemove + " from the map.");
        populationMap.remove(countryToRemove);

        // Printing the map after removal
        System.out.println("\nMap after removal:");
        for (Map.Entry<String, Integer> entry : populationMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
