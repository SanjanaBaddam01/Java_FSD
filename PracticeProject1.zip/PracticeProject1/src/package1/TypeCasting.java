package package1;

public class TypeCasting {

	public static void main(String[] args) {
		// Implicit casting (Widening)
        int intValue = 10;
        double doubleValue = intValue; // Implicit casting from int to double
        System.out.println("Implicit Casting: int to double - Result: " + doubleValue);

        // Explicit casting (Narrowing)
        double anotherDoubleValue = 15.75;
        int anotherIntValue = (int) anotherDoubleValue; // Explicit casting from double to int
        System.out.println("Explicit Casting: double to int - Result: " + anotherIntValue);

        // Be cautious with explicit casting, as it may result in loss of precision
        double largeDoubleValue = 123456789.123456789;
        int largeIntValue = (int) largeDoubleValue; // Loss of precision
        System.out.println("Explicit Casting with Loss of Precision: double to int - Result: " + largeIntValue);

	}

}
